# <img src="https://github.com/Ran-n/media/blob/main/empresas/coing_gecko_01.svg" width="50" alt="CoinGecko" title="CoinGecko"> coingecko\_api



Python wrapper for the [CoinGecko](https://www.coingecko.com/en) API(v3) with GPLv3 license.

Documentation of the API at [<img src="https://github.com/Ran-n/media/blob/main/empresas/coing_gecko_03.svg" width="100" alt="CoinGecko" title="CoinGecko">](https://www.coingecko.com/en/api/documentation?)
